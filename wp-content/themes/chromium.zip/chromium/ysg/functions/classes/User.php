<?php

if (!function_exists('add_action')) {
    echo 'You cannot access directly.';
    exit;
}

class User
{
    public function __construct()
    {
    }

    public function canCancelOrder()
    {
    }
}
